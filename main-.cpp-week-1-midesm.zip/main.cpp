/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    string indexNumber;

public:
    Student(string n, string i) {
        name = n;
        indexNumber = i;
    }

    // Save student to file
    void saveToFile() {
        ifstream checkFile("students.txt");
        string line;

        // Prevent duplicate index numbers
        while (getline(checkFile, line)) {
            if (line.find(indexNumber) != string::npos) {
                cout << "Student with this index number already exists!\n";
                checkFile.close();
                return;
            }
        }
        checkFile.close();

        ofstream file("students.txt", ios::app);
        file << name << "," << indexNumber << endl;
        file.close();

        cout << "Student registered successfully!\n";
    }

    // View all students
    static void viewStudents() {
        ifstream file("students.txt");
        string line;

        cout << "\n===== REGISTERED STUDENTS =====\n";

        if (!file) {
            cout << "No students registered yet.\n";
            return;
        }

        while (getline(file, line)) {
            cout << line << endl;
        }

        file.close();
    }

    // Search student by index number
    static void searchStudent(string index) {
        ifstream file("students.txt");
        string line;
        bool found = false;

        while (getline(file, line)) {
            if (line.find(index) != string::npos) {
                cout << "Student Found: " << line << endl;
                found = true;
                break;
            }
        }

        if (!found) {
            cout << "Student not found.\n";
        }

        file.close();
    }
};

int main() {
    int choice;

    do {
        cout << "\n===== STUDENT MANAGEMENT SYSTEM =====\n";
        cout << "1. Register Student\n";
        cout << "2. View All Students\n";
        cout << "3. Search Student by Index\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string name, index;

            cin.ignore();
            cout << "Enter Student Name: ";
            getline(cin, name);

            cout << "Enter Index Number: ";
            getline(cin, index);

            Student s(name, index);
            s.saveToFile();
        }

        else if (choice == 2) {
            Student::viewStudents();
        }

        else if (choice == 3) {
            string index;
            cout << "Enter Index Number to Search: ";
            cin >> index;

            Student::searchStudent(index);
        }

    } while (choice != 0);

    cout << "Program exited.\n";

    return 0;
}